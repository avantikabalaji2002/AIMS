## Using Firebase Cloud Storage with React to Upload Files to Cloud

### This repo shows how to create use firebase storage to upload and download files to cloud from a React web App

### Youtube Tutorial Link - https://youtu.be/mEf-6IUsTKs

#### 📚 Materials/References:

Firebase: https://firebase.google.com

Firebase Storage: https://firebase.google.com/docs/storage
